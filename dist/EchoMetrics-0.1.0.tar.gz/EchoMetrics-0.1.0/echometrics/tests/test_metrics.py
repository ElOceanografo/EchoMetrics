from echometrics import *
import numpy as np
import pandas
from fixtures import *
from nose import with_setup

@with_setup(make_simple_data)
def test_depth_integral():
    echo = Echogram(data['data'], data['depth'], data['index'])
    integral = depth_integral(echo)
    integral_lin = depth_integral(echo, dB_result=False)
    assert len(integral) == echo.data.shape[1]
    assert len(integral) == len(echo.index)
    assert np.all(integral == to_dB(echo.dz * to_linear(simple_data_max)))
    assert np.all(integral_lin == echo.dz * to_linear(simple_data_max))

@with_setup(make_simple_data)
def test_depth_integral_range():
    echo = Echogram(data['data'], data['depth'], data['index'])
    echo.data[-1, :] = simple_data_max
    integral = depth_integral(echo, range=[3,5])
    print integral
    assert np.all(integral == to_dB(echo.dz * to_linear(simple_data_max)))
    # no samples from within range
    integral = depth_integral(echo, range=[5, 10])
    assert np.all(integral.mask)

@with_setup(make_simple_data)
def test_sv_avg():
    echo = Echogram(data['data'], data['depth'], data['index'])
    avg = sv_avg(echo)
    assert len(avg) == len(echo.index)
    assert np.all(avg == simple_data_max)
    avg = sv_avg(echo, dB_result=False)
    assert np.all(avg == to_linear(simple_data_max))

@with_setup(make_simple_data)
def test_center_of_mass():
    echo = Echogram(data['data'], data['depth'], data['index'])
    cm = center_of_mass(echo)
    assert len(cm) == len(echo.index)
    assert np.all(cm == 2)

@with_setup(make_simple_data)
def test_inertia():
    echo = Echogram(data['data'], data['depth'], data['index'])
    inert = inertia(echo)
    assert len(inert) == len(echo.index)
    assert np.all(inert == 0)
    echo.data[-1, :] = simple_data_max
    inert = inertia(echo)
    assert np.all(inert == 1)

@with_setup(make_simple_data)
def test_proportion_occupied():
    echo = Echogram(data['data'], data['depth'], data['index'])
    p_occ = proportion_occupied(echo)
    assert len(p_occ) == len(echo.index)
    print p_occ
    assert np.all(p_occ == 0.2)
    echo.data[0] = simple_data_max
    p_occ = proportion_occupied(echo)
    assert np.all(p_occ == 0.4)

@with_setup(make_simple_data)
def test_aggregation_index():
    echo = Echogram(data['data'], data['depth'], data['index'])
    agg = aggregation_index(echo)
    assert len(agg) == len(echo.index)
    assert np.all(agg == 1)
    echo.data[0] = simple_data_max
    agg = aggregation_index(echo)
    assert np.all(agg == 0.5)
    echo.data[-1] = simple_data_max
    agg = aggregation_index(echo)
    assert np.all(agg == 1/3.)

@with_setup(make_simple_data)
def test_equivalent_area():
    echo = Echogram(data['data'], data['depth'], data['index'])
    eq = equivalent_area(echo)
    assert len(eq) == len(echo.index)
    assert np.all(eq == 1)
    echo.data[0] = simple_data_max
    eq = equivalent_area(echo)
    assert np.all(eq == 2)
    echo.data[-1] = simple_data_max
    eq = equivalent_area(echo)
    assert np.all(eq == 3)

def test_nlayers():
    names = {'data' : 'Data_values', 'depth' : 'Depth', 'index' : 'Ping_time'}
    echo = read_mat('data/MARS-D20100308-T234901-depth.mat', names)
    layers = nlayers(echo)