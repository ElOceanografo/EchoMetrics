import numpy as np
from echometrics import *
from fixtures import data, make_simple_data
from nose import with_setup

        
@with_setup(make_simple_data)
def test_check_dimensions_depth():
    try:
        Echogram(data['data'],  data['depth'][1:], data['index'])
    except AssertionError as err:
        assert type(err) == AssertionError


@with_setup(make_simple_data)
def test_check_dimensions_index():
    try:
        Echogram(data['data'],  data['depth'], data['index'][1:])
    except AssertionError as err:
        assert type(err) == AssertionError


@with_setup(make_simple_data)
def test_check_dimensions_threshold():
    # Threshold too small
    try:
        Echogram(data['data'], data['depth'], data['index'], threshold=[0])
    except AssertionError as err:
        assert type(err) == AssertionError
    # Threshold too big
    try:
        Echogram(data['data'], data['depth'], data['index'], threshold=[0, 1, 2])
    except AssertionError as err:
        assert type(err) == AssertionError
    # Default threshold
    Echogram(data['data'], data['depth'], data['index'])

@ with_setup(make_simple_data)
def test_check_dimensions_bad_data():
    try:
        Echogram(data['data'], data['depth'], data['index'], bad_data=data['data'][1:])
    except AssertionError as err:
        assert type(err) == AssertionError

@with_setup(make_simple_data)
def test_check_dimensions_dz():
    depth = data['depth']
    depth[-1] = 500
    try:
        Echogram(data['data'], depth, data['index'], bad_data=data['data'][1:])
    except AssertionError as err:
        assert type(err) == AssertionError


@with_setup(make_simple_data)
def test_set_scale():
    echo = Echogram(data['data'], data['depth'], data['index'])
    assert echo.scale == 'decibel'
    d = np.copy(echo.data)
    # transform to linear
    echo.set_scale('linear')
    assert echo.scale == 'linear'
    assert np.all(echo.data == 10**(d / 10.))
    # try to transform to linear again
    echo.set_scale('linear')
    assert echo.scale == 'linear'
    assert np.all(echo.data == 10**(d / 10.))
    # transform back to dB
    echo.set_scale('decibel')
    assert echo.scale == 'decibel'
    assert np.all(echo.data == d)
    # try to transform to decibel again
    assert echo.scale == 'decibel'
    assert np.all(echo.data == d)


def check_threshold(echo, threshold):
    threshold = tuple(threshold)
    assert (max(echo.threshold), min(echo.threshold)) == threshold
    assert echo.data.min() >= min(echo.threshold)
    assert echo.data.max() <= max(echo.threshold)

    
@with_setup(make_simple_data)
def test_set_threshold():
    echo = Echogram(data['data'], data['depth'], data['index'], threshold=[0, -70])
    # make sure constructor worked
    check_threshold(echo, [0, -70])
    # try changing threshold
    echo.set_threshold([0, -80])
    check_threshold(echo, [0, -80])
    # make sure method raises errors when threshold is of length != 2
    try:
        echo.set_threshold([0, -80, 3])
    except ValueError as err:
        assert type(err) == ValueError
    try:
        echo.set_threshold([0])
    except ValueError as err:
        assert type(err) == ValueError
    

@with_setup(make_simple_data)
def test_flip():
    data['data'][0, :] = -1
    echo = Echogram(data['data'], data['depth'], data['index'])
    echo.flip()
    assert np.all(echo.data[-1, :] == data['data'][0, :])
    assert np.all(echo.data.data[-2, :] == data['data'][1, :])
    assert echo.depth[-1] == data['depth'][0]
    assert echo.depth[-2] == data['depth'][1]

def test_read_mat():
    file = 'data/MARS-D20100308-T234901-depth.mat'
    names = {'data' : 'Data_values', 'depth' : 'Depth', 'index' : 'Ping_time'}
    echo = read_mat(file, names)
    assert type(echo) == echometrics.Echogram

def test_read_flat():
    file = 'data/Sept17_DVM_int_cope38.csv'
    echo = read_flat(file, ['Lat_M', 'Lon_M'], 'Layer', 'Sv_mean')
    assert type(echo) == echometrics.Echogram